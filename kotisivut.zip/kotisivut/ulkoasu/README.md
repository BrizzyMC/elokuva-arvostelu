Tässä tiedostossa on css & javascript koodi jota html tarvitsee
TODO kirjoita lisää kommenttia ja avaa kansion roolia

"""
=================================================================

Nimi:       rajapinta.py
kuvaus:     Tiedosto pitäää sisällään functiot jotka kommunikoivat
            verkko rajapinnan kanssa ja vastaavat sivulla
            tapahtuvasta tiedon käsittelystä.

Tekiä:      Viljam Vänskä
Päivämäärä: 26.9.2025
Versio:     1.1

=================================================================
"""

from flask import redirect, url_for, request, Blueprint, session
from .tietokanta.sql import sql_yhteys
import requests


__tietokanta = sql_yhteys()

rajapinta = Blueprint('rajapinta', __name__)


# > ------------ [ Toiminto Functiot ] ------------------------ <

@rajapinta.route('/')
def tarkista_kirjautuminen():
    """
    Tarkistaa onko käyttäjä kirjautunut sisään, tieto hankitaan sessiota käyttäen
    
    Vaihtoehdot:
        - Kyllä: Ohjataan kotisivulle
        - Ei: Ohjataan käyttäjän luontiin
    """
    if session.get('kayttaja_id'):
        kayttaja_nimi = __tietokanta.kayttajan_tiedot(session['kayttaja_id'])[0]['nimi']
        print(kayttaja_nimi)
        return redirect(url_for('Sivut.koti', nimi=kayttaja_nimi))
        
    else:
        return redirect(url_for('Sivut.kirjaudu_sisaan'))



@rajapinta.route('/kirjaudu/luodaan_kayttaja', methods=['POST'])
def luo_kayttaja():
    """
    POST /luo_käyttäjä/luodaan
    ---
    Luo käyttäjän ja ohjaa kotisivulle
    """

    if request.method == 'POST':
        kayttaja = request.form['kayttaja']
        salasana = request.form['salasana']

        try:
            __tietokanta.lisaa_kayttaja(kayttaja, salasana)
            session['kayttaja_id'] = __tietokanta.kirjaudu(kayttaja, salasana) # Käyttäjä kirjataan sisään ja id tallennetaan sessioon
            session['nimi'] = kayttaja

            return redirect(url_for('Sivut.koti', nimi=kayttaja))

        except NameError:
            return redirect(url_for('Sivut.luo_käyttäjä'))
        


@rajapinta.route('/kirjaudu/kirjataan_sisaan', methods=['POST'])
def kirjaudu():
    """
    POST /kirjaudu/kirjataan_sisaan
    ---
    Kirjaa käyttäjän sisään ja ohjaa kotisivulle
    """

    if request.method == 'POST':
        kayttaja = request.form['kayttaja']
        salasana = request.form['salasana']

        try:
            session['kayttaja_id'] = __tietokanta.kirjaudu(kayttaja, salasana)
            session['nimi'] = kayttaja
            
            return redirect(url_for('Sivut.koti', nimi=kayttaja))

        except ValueError:
            return redirect(url_for('Sivut.kirjaudu_sisaan'))

        except TypeError:
            return redirect(url_for('Sivut.kirjaudu_sisaan'))



@rajapinta.route('/haku', methods=['POST'])
def hae():
    """
    POST /haku
    ---
    Hakee elokuvia hakusanan perusteella

    Palauttaa:
        - Löytyneet elokuvat
    """

    if request.method == 'POST':
        hakusana = request.form['hakusana']
        elokuvat = __tietokanta.hae_elokuvia(hakusana)

        return elokuvat



@rajapinta.route('/kayttaja_tiedot', methods=['POST'])
def kayttaja_tiedot():
    """
    POST /kayttaja_tiedot
    ---
    Hakee käyttäjätietoja käyttäjä id:n perusteella

    Palauttaa:
        - Käyttäjän tiedot
    """

    if request.method == 'POST':
        kayttaja_id = request.form['kayttajatiedot']
        tiedot = __tietokanta.kayttajan_tiedot(int(kayttaja_id))

        return tiedot



@rajapinta.route('/paivita_kayttajaa', methods=['POST'])
def paivita_nimi_salasana(kayttaja_id:int=1):
    """
    POST /paivita_kayttajaa
    ---
    Päivittää nimen, salasanan ja ohjaa kotisivulle

    HUOM:
        - Jos kenttä on tyhjä niin se jätetään huomiotta
    """

    if request.method == 'POST':
        uusi_nimi     = request.form['nimi']
        uusi_salasana = request.form['salasana']

        if uusi_nimi:
            __tietokanta.muuta_kayttajanimea(kayttaja_id, uusi_nimi)

        if uusi_salasana:
            __tietokanta.muuta_salasanaa(kayttaja_id, uusi_nimi)

        return redirect(url_for('Sivut.kirjaudu_sisaan'))



@rajapinta.route('/lisää_arvostelu', methods=['POST'])
def lisaa_arvostelu():
    """
    POST /lisää_arvostelu
    ---
    Lisää arvostelun tietokantaan
    """

    if request.method == 'POST':
        arvosana  = request.form['arvosana']
        kommentti = request.form['kommentti']

        __tietokanta.lisaa_arvostelu(1, int(arvosana), 1, kommentti)

        return [arvosana, kommentti]



@rajapinta.route('/muokkaa_kommenttia', methods=['POST'])
def muokkaa_kommentti():
    """
    POST /muokkaa_kommenttia
    ---
    Muokkaa kommenttia
    """

    if request.method == 'POST':
        kommentti = request.form['kommentti']

        try:
            __tietokanta.muokkaa_kommenttia(1, kommentti)

        except ValueError:
            redirect(url_for('Sivut.muokkaa_kommenttia'))

    return [kommentti]



@rajapinta.route('/kirjaudu_ulos', methods=['POST'])
def kirjaudu_ulos():
    """
    POST /kirjaudu_ulos
    ---
    Kirjaa käyttäjän ulos ja ohjaa kirjautumis sivulle

    Ohjaa:
        - Kirjautumis sivu
    """

    if request.method == 'POST':
        session.pop('nimi')
        session.pop('kayttaja_id')

        return redirect(url_for('Sivut.kirjaudu_sisaan'))



@rajapinta.route('/lähetä_elokuvan_tiedot', methods=['POST'])
def laheta_elokuvan_tiedot():
    """
    POST /lähetä_elokuvan_tiedot
    ---
    Lähettää elokuvan nimen (str) ja loput tiedot (dict) sivun lataus functiolle

    Ohjaa:
        - Elokuvan tiedot sivu
    """

    if request.method == 'POST':
        # Hankkii elokuvan tiedot dict muodossa
        elokuva = __tietokanta.elokuva_id_dict(1)

        arvostelut = __tietokanta.elokuvan_arvostelut(1)

        return redirect(url_for('Sivut.elokuvan_tiedot',kayttaja_nimi=session['nimi'], **elokuva))



            

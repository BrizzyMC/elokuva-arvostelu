# Sovellus

Kansio sisältää Flask rajapinnan ja nettisivujen reitit.

---

### Logiikka

Rakenteen toiminta logiikka on seuraava, **rajapinta.py** pitää sisällään Flask functiot jotka jotka kommunikoivat nettisivujen kanssa. **sivut.py** pitää sisällään html sivujen url ohjauksen.
**init** rekistöröi rajapinnan ja sivujen blueprintit jotta ne on helppo kutsua palvelimen käyttöön.

<img width="890" height="567" alt="image" src="https://github.com/user-attachments/assets/204b0220-9312-4eab-beb9-43b55395d14a" />

---

### Simppelöity esimerkki logiikasta

<img width="550" height="490" alt="image" src="https://github.com/user-attachments/assets/a47e4865-e23b-4b9a-9f47-a100811f074a" />

---

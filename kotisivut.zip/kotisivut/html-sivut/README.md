[suunitelma](https://www.figma.com/design/3aXEThs6c5S6PgLKsaTRd2/Untitled?node-id=1-2&t=E99Yq9zyStxHpczm-1)

Lisätty prototyypi figma suunnitelmaan
